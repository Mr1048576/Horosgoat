module Bootstrap
  VERSION = '3.2.0.2'
  BOOTSTRAP_SHA = 'c068162161154a4b85110ea1e7dd3d7897ce2b72'
end
